#include <stdio.h>

int
main (void)
{
  printf("Value of NUM is %d\n", NUM);
  return 0;
}
