#include "buffer.h"
template class Buffer<float>;
