#include "hello.h"

int
main (void)
{
  hello ("world");
  return 0;
}
