#include "hello.h"

int
main (void)
{
  hello ("everyone");  /* changed from "world" */
  return 0;
}
