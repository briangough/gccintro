void hello (const char * name);
void bye (void);
