void 
f (const char * str)
{
  char * s = (char *)str;
  s[0] = '\0';
}
