#include <stdio.h>  

int
main (void)
{
  double x = pow (2.0, 3.0);
  printf ("Two cubed is %f\n", x);
  return 0;
}
