#include <stdio.h>

int
main (void)
{
  printf ("HELLO WORLD!\N");
  return 0;
}
