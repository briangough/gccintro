#include <stdio.h>

int
display (const char * str)
{
  printf ("%s\n", str);
}
