#include <stdio.h>

int
main (void)
{
  printf ("Ten times NUM is %d\n", 10 * (NUM));
  return 0;
}
