#define TEST "Hello, World!"
const char str[] = TEST;
