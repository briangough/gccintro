#include <stdio.h>

int
main (void)
{
  printf ("Value of NUM is %d\n", 2+2);
  return 0;
}
