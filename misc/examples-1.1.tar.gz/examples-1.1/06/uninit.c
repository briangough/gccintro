int 
sign (int x)
{
  int s;
  
  if (x > 0)
    s = 1;
  else if (x < 0)
    s = -1;
  
  return s;
}
