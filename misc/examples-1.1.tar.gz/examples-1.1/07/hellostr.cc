#include <string>
#include <iostream>

using namespace std;

int
main ()
{
  string s1 = "Hello,";
  string s2 = "World!";
  cout << s1 + " " + s2 << '\n';
  return 0;
}
